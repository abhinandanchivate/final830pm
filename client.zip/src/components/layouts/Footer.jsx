import React, { Component } from "react";

export default class Footer extends Component {
  render() {
    return <>devconnector {new Date().getFullYear()} &copy; www.kh.com</>;
  }
}
